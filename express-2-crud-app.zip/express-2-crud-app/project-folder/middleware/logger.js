const logger = (req, res, next) => {
    console.log(`Request received at: ${new Date().toISOString()}`);
    next();
  };
  
  module.exports = logger;
  